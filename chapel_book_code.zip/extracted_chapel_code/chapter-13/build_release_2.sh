      - name: Perf smoke
        if: github.event_name == 'pull_request'
