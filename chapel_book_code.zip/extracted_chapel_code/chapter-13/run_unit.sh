#!/usr/bin/env bash
set -euo pipefail
for t in test/unit/*.chpl; do
  chpl "$t" -o /tmp/$(basename "$t" .chpl)
  "/tmp/$(basename "$t" .chpl)"
