      - name: Docs (chpldoc)
        run: |
          mkdir -p site && chpldoc --no-html --save-sphinx site src libs
