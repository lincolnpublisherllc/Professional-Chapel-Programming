  tools/
    ci/
      ci.env              # shared env
