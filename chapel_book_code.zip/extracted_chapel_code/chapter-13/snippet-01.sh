files = list(pathlib.Path('src').rglob('*.chpl')) + list(pathlib.Path('libs').rglob('*.chpl'))
pub = 0; docd = 0
