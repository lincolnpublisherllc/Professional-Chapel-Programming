#!/usr/bin/env bash
set -euo pipefail
mason build -- --fast
