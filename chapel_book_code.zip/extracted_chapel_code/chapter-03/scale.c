extern proc scale_d(a: c_ptr(real(64)), n: c_size_t, k: real(64)): void;

proc scaleDense(ref A: [] real(64), k: real(64)) {
  // Defend the contract
  assert(A.rank == 1 && A.domain.stridable == false, "expect dense 1D");
  const n = A.domain.size:c_size_t;
  const p = c_ptrTo(A[A.domain.low]);
  scale_d(p, n, k);
}
