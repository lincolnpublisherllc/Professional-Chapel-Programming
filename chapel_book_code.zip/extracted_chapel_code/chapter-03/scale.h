void scale_d(double* a, size_t n, double k) {
  for (size_t i=0; i<n; i++) a[i] *= k;
}
