void scale_d(double* a, size_t n, double k);
