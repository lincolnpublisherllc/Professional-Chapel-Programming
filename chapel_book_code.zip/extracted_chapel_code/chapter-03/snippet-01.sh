Dev: mason build (no --fast), assertions on, small datasets, randomized tests, cross-checks enabled (hist vs P²).
Prod: mason build -- --fast, no per-record checks, validated inputs, large bins chosen by memory budget, structured logs only at start/end of stages.
