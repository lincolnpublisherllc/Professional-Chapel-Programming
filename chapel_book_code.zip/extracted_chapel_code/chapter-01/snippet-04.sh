mason doc        # HTML under ./doc
