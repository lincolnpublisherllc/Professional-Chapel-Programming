RUN apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y \
    build-essential git curl python3 ca-certificates && rm -rf /var/lib/apt/lists/*
