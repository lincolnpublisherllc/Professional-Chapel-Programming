CHPL="$(chpl --version | head -n1)"
JQ='{"version":"'"$VER"'","chpl":"'"$CHPL"'","built_at":"'"$(date -u +%FT%TZ)"'","git":"'"$(git rev-parse HEAD)"'"}'
echo "${JQ}" > "${OUT}"
Release script (excerpt)
