#!/usr/bin/env bash
set -euo pipefail
MODE="${1:-debug}"   # debug|release
