CMD ["bin/app", "--help"]
