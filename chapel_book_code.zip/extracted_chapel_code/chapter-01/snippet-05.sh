set -euo pipefail
module load chapel/1.34   # or source your env
