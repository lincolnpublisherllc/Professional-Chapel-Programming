PKG="dist/ana-${VER}-linux-x86_64"
mkdir -p "${PKG}/doc"
cp -r doc/* "${PKG}/doc/" 2>/dev/null || true
