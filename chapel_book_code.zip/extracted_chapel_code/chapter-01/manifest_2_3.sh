tar -C dist -czf "dist/ana-${VER}.tar.gz" "$(basename "${PKG}")"
