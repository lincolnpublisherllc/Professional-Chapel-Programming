module version {
  config const APP_VERSION: string = "dev";
  config const BUILD_MODE:  string = "debug";
  config const TELEMETRY:   bool   = false; // opt-in only
  proc banner() {
    writeln("version=", APP_VERSION, " mode=", BUILD_MODE,
            " chpl=", CHPL_VERSION, " localeCount=", numLocales);
  }
}
