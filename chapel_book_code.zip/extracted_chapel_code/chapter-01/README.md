cp -r bin/app "${PKG}/bin/"
