mason test
