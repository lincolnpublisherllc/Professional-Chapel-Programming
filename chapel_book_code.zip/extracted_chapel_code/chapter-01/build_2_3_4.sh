    - name: Tests
      run: mason test
  docs:
    runs-on: ubuntu-22.04
    steps:
    - uses: actions/checkout@v4
    - name: Setup Chapel
      run: (same as above)
    - name: Docs
      run: mason doc
    - uses: actions/upload-artifact@v4
      with: { name: docs, path: doc/ }
