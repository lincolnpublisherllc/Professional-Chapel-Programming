If you use GitHub Actions, a simple pipeline looks like:
name: ci
on: [push, pull_request]
jobs:
  build-test:
    runs-on: ubuntu-22.04
    strategy:
      matrix:
        mode: [debug, release]
    steps:
    - uses: actions/checkout@v4
    - name: Setup Chapel
      run: |
        curl -fsSL -o chpl.tgz https://your.mirror/chapel-1.34.0-linux-x86_64.tar.gz
        sudo tar -xzf chpl.tgz -C /opt && echo "/opt/chapel/bin/linux64-x86_64" | sudo tee -a /etc/environment
        echo "CHPL_HOME=/opt/chapel" | sudo tee -a /etc/environment
        echo "/opt/chapel/bin/linux64-x86_64" >> $GITHUB_PATH
    - name: Build ${{ matrix.mode }}
      run: |
