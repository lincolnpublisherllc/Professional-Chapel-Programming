GIT_DESCRIBE="$(git describe --tags --dirty 2>/dev/null || true)"
if [[ -z "${GIT_DESCRIBE}" ]]; then
  GIT_DESCRIBE="0.0.0-$(date +%Y%m%d)-$(git rev-parse --short HEAD)"
