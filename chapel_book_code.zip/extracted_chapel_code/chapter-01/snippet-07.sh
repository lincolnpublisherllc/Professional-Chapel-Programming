RUN curl -fsSL -o chpl.tar.gz https://example.invalid/chapel-${CHPL_VERSION}-linux-x86_64.tar.gz \
