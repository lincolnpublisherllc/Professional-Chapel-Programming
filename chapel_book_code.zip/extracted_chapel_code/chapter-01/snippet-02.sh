echo "== Building ${APP} [${MODE}] version=${VER}"
chpl "${APP}" "${CHPL_FLAGS[@]}" -o "bin/$(basename "${APP%.chpl}")"
