Write unit + golden tests; wire a tiny CI (build + tests + docs).
