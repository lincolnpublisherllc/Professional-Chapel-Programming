Dev: mason build (checks on).
Release: mason build -- --fast; embed version banner (commit, build date).
